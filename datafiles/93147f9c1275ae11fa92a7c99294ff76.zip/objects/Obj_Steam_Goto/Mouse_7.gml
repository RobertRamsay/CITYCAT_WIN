
room_goto(targetRoom)

