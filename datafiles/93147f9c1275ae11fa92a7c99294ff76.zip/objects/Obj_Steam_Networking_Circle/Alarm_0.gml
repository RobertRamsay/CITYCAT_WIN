
instance_destroy()

