{
  "%Name": "Steamworks_Definitions",
  "isCompatibility": false,
  "isDnD": false,
  "name": "Steamworks_Definitions",
  "parent": {
    "name": "Steamworks",
    "path": "folders/Steamworks.yy",
  },
  "resourceType": "GMScript",
  "resourceVersion": "1.0",
}